import { get } from 'http';
import ObjectContenedor from './contenedor/objectContenedor.js';

const objectService = new ObjectContenedor();
const environment = async() =>{
    console.log("obteniendo objetos");
    let objects = await objectService.getAllObjects();

    console.log(objects);

    console.log("agregando un objecto");
    let object ={
        name:"maceta",
        note:""
    };
    //await objectService.addObject(object);
    //let elemento = await objectService.getById(2);
    //console.log(elemento);
   console.log(objectService.deleteAll(object));
    //console.log(objectService.getById(4));
    //await objectService.deleteById();
}


environment();