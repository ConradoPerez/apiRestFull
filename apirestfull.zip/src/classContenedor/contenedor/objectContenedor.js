import fs from 'fs';

const path = './src/classContenedor/files/objects.json';

class ObjectContenedor{
    getAllObjects = async() => {
        try{
            if(fs.existsSync(path)){
                let fileData = await fs.promises.readFile(path,'utf8');
                let objects = JSON.parse(fileData);
                return objects;
            }else{
                return [];
            }
        }catch(error){
            console.log("cannot read file:"+error);
        }
    }
    addObject = async(object) =>{
        try{
            let objects = await this.getAllObjects();
            if(objects.length===0){
                object.id=1;
                objects.push(object);
                await fs.promises.writeFile(path,JSON.stringify(objects,null,'\t'));
                return object.id;
            }else{
                object.id = objects[objects.length-1].id+1;
                objects.push(object);
                await fs.promises.writeFile(path,JSON.stringify(objects,null,'\t'));
                return object.id;
            }
        }catch(error){
            console.log("cannot write file: "+ error);
        }
    }
    getById= async(id) => {
        const data = await this.getAllObjects();
        return data.find((object) => object.id == id);
    }
    deleteById = async (id)=>{
        try {
            const data = await this.getAllObjects();
            let borrar = data.filter((object)=> object.id !== id)
            await fs.promises.writeFile(path,JSON.stringify(borrar,null,'\t'));
        } catch (error) {
            console.log('Hay un error'+ error);
        }
    }//hasta aca funciona
   deleteAll = async(object)=>{
        try {
            const data = await this.getAllObjects();
              let borrarTodo = data.map(object);
              
              
            }
            
            //await fs.promises.writeFile(path,JSON.stringify(borrar,null,'\t'));
            //console.log("Archivo eliminado:" + JSON.stringify(data));
         catch (error) {
            console.log('Hay un error'+ error);
        }
    }
    actualizar = async(obj) =>{
        let arr = await this.getAllObjects()
        let id = obj.id;
        let titulo = obj.title;
        let price = obj.prices;
        let thumbnail = obj.thumbnail;
        arr.map(function(dato){
            if(dato.id == id){
                dato.title = titulo;
                dato.prices = price;
                dato.thumbnail = thumbnail;
            }
        })
        await fs.promises.writeFile(path,JSON.stringify(arr,null,'\t'));
        console.log(arr)
        return arr;
    }
}


export default ObjectContenedor;