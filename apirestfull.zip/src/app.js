import express from 'express';
import productsRouter from './routes/products.router.js';
import __dirname from './utils.js';
import handlebars from 'express-handlebars';
import viewsRouter from './routes/views.router.js';

const app = express();

app.use(express.static(__dirname+'/public'));
const server = app.listen(8080,()=>console.log("now listening on port 8080"));
app.use(express.json());
app.use('/api/productos',productsRouter);
app.use(express.static('public'));

app.engine('handlebars', handlebars.engine())
app.set('views',__dirname+'/views');
app.set('view engine','handlebars');

app.use('/',viewsRouter);