import { Router } from "express";
import ObjectContenedor from "../classContenedor/contenedor/objectContenedor.js";
const nuevaInfo = new ObjectContenedor();
const router = Router();

router.get('/',async(req,res)=>{
    let getAllProducts = await nuevaInfo.getAllObjects();
    res.send(getAllProducts);
})
router.get('/:id',async(req,res)=>{
    let returnById = await nuevaInfo.getById(req.params.id);
    res.send(returnById);
    console.log(returnById);
    //falta que redirija a la pagina con el objeto encontrado
})
router.post('/',async(req,res)=>{
    console.log(req.body);
    let addProduct = await nuevaInfo.addObject(req.body);
    res.send({addProduct});
})
router.put('/',async(req,res)=>{
    let upgradeById = await nuevaInfo.getById(req.params.id);
//no me anda
})
router.delete('/',async(req,res)=>{
    let id = req.params.id;
    await nuevaInfo.deleteById(req.params.id);
    res.send("Eliminado");
    console.log("producto eliminado");
})

export default router;