
import {Router} from "express";
import objectContenedor from "../classContenedor/contenedor/objectContenedor.js";

const router = Router();
const nuevaInfo = new objectContenedor();
router.get('/',(req,res)=>{
    res.render('welcome')
})

router.get('/newObject', (req,res)=>{
    res.render('newObject');
})

router.get('/object',async(req,res)=>{
    let object = await nuevaInfo.getAllObjects();
    res.render('object',{
        object,
        name: "Carlos"
    });
    let getAllProducts = await nuevaInfo.getAllObjects();
    res.send(getAllProducts);
})

export default router;